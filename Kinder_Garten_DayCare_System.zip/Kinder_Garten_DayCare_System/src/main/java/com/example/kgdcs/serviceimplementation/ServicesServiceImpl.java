package com.example.kgdcs.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.kgdcs.entity.Services;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.ServicesRepository;
import com.example.kgdcs.service.ServicesService;

@Service
public class ServicesServiceImpl implements ServicesService {
    @Autowired
	 private ServicesRepository ServicesRepo;
    
	@Override
	public Services addServices(Services Services) {
		return ServicesRepo.save(Services);
	}

	@Override
	public List<Services> getAllServicess() {
		return ServicesRepo.findAll();
	}

	@Override
	public Services getServicesById(Long ServicesId) {
		Services s;
		Optional<Services>services=ServicesRepo.findById(ServicesId);
		if(services.isPresent())
		{
		 s=services.get();
		}
		else
		{
			throw new ResourceNotFoundException("Services","ServicesId",ServicesId);
		}
		return s;
	}

	@Override
	public Services updateServices(Long ServicesId,Services Services) {
		Services u=ServicesRepo.findById(ServicesId).get();
		u.setServicename(Services.getServicename());
		u.setServicedetail(Services.getServicedetail());
		u.setCreationdate(Services.getCreationdate());
		return ServicesRepo.save(u);
	}

	@Override
	public Services deleteServicesById(Long ServicesId) {
		 Optional<Services> servicesOptional = ServicesRepo.findById(ServicesId);
		    if (servicesOptional.isPresent()) {
		    	ServicesRepo.deleteById(ServicesId);
		    } else {
		        throw new ResourceNotFoundException("Services", "ServicesId", ServicesId);
		    }
			return null;
		}
	
	@Override
	public void deleteAllServices() {
		ServicesRepo.deleteAll();
		
	}

	@Override
	public boolean isServicesExists(Long ServicesId) {
		return ServicesRepo.existsById(ServicesId);
	}

}



