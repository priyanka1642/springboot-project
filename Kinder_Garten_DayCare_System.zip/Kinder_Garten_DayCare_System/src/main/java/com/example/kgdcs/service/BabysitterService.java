package com.example.kgdcs.service;

import java.util.List;
import com.example.kgdcs.entity.Babysitter;

public interface BabysitterService {
Babysitter addBabysitter(Babysitter Babysitter);
	
	List<Babysitter> getAllBabysitters();
	
	Babysitter getBabysitterById(Long BabysitterId);
	
	Babysitter updateBabysitter(Long BabysitterId,Babysitter Babysitter);
	
	Babysitter deleteBabysitterById(Long BabysitterId);
	
	void deleteAllBabysitter();
	
	boolean isBabysitterExists(Long BabysitterId);
	

}

