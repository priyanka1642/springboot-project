package com.example.kgdcs.serviceimplementation;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.kgdcs.entity.EnrollForm;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.EnrollRepository;
import com.example.kgdcs.service.EnrollFormService;

@Service
public class EnrollFormServiceImpl implements EnrollFormService {
    @Autowired
	 private EnrollRepository EnrollFormRepo;
    
	@Override
	public EnrollForm addEnrollForm(EnrollForm EnrollForm) {
		return EnrollFormRepo.save(EnrollForm);
	}

	@Override
	public List<EnrollForm> getAllEnrollForms() {
		return EnrollFormRepo.findAll();
	}

	@Override
	public EnrollForm getEnrollFormById(Long EnrollFormId) {
		
		EnrollForm e;
		
		Optional<EnrollForm> enrollForm=EnrollFormRepo.findById(EnrollFormId);
		if(enrollForm.isPresent())
		{
		 e=enrollForm.get();
		}
		else
		{
			throw new ResourceNotFoundException("EnrollForm","EnrollFormId",EnrollFormId);
		}
		return e;
	}
	

	@Override
	public EnrollForm updateEnrollForm(Long EnrollFormId,EnrollForm EnrollForm) {
		EnrollForm e=EnrollFormRepo.findById(EnrollFormId).get();
		e.setParentName(EnrollForm.getParentName());
		e.setChildName(EnrollForm.getChildName());
		e.setGender(EnrollForm.getGender());
		e.setDob(EnrollForm.getDob());
		e.setProgramName(EnrollForm.getProgramName());
		e.setPhoneNumber(EnrollForm.getPhoneNumber());
		e.setPayment(EnrollForm.getPayment());
		e.setAddress(EnrollForm.getAddress());
		e.setCity(EnrollForm.getCity());
		//e.setZipcode(EnrollForm.getZipcode());
		e.setDate(EnrollForm.getDate());
		return EnrollFormRepo.save(e);
	}

	@Override
	public EnrollForm deleteEnrollFormById(Long EnrollFormId) {
		  Optional<EnrollForm> enrollFormOptional = EnrollFormRepo.findById(EnrollFormId);
		    if (enrollFormOptional.isPresent()) {
		    	EnrollFormRepo.deleteById(EnrollFormId);
		    } else {
		        throw new ResourceNotFoundException("EnrollForm", "EnrollFormId", EnrollFormId);
		    }
			return null;
		}	
		
		
	@Override
	public void deleteAllEnrollForm() {
		EnrollFormRepo.deleteAll();
		
	}

	@Override
	public boolean isEnrollFormExists(Long EnrollFormId) {
		return EnrollFormRepo.existsById(EnrollFormId);
	}

}



