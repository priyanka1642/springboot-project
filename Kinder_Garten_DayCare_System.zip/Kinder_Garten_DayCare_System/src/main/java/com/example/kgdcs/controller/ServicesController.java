package com.example.kgdcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.kgdcs.entity.Services;
import com.example.kgdcs.service.ServicesService;

@RestController
@RequestMapping("/services")
public class ServicesController {
	@Autowired
	private ServicesService ServicesService;
	
	@PostMapping("/add")
	public ResponseEntity<Services> addServices(@RequestBody Services Services)
	{
		Services s=ServicesService.addServices(Services);
		return new ResponseEntity<>(s,HttpStatus.CREATED);
	}
	@GetMapping("/get/{ServicesId}")
	public Services getServices(@PathVariable Long ServicesId)
	{
		
			return ServicesService.getServicesById(ServicesId);
		}
//	public ResponseEntity<Services> getServices(@PathVariable Long ServicesId)
//	{
//		boolean isServices=ServicesService.isServicesExists(ServicesId);
//		if(isServices)
//		{
//			Services s=ServicesService.getServicesById(ServicesId);
//			return new ResponseEntity<>(s,HttpStatus.OK);
//		}
//		else
//		{
//			System.out.print("No Services found");
//			return null;
//		}
//	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Services>> getAllServices(){
		return new ResponseEntity<>(ServicesService.getAllServicess(),HttpStatus.OK);
	}
	@PutMapping("/update/{ServicesId}")
	public ResponseEntity<Services> updateServices(@PathVariable Long ServicesId,@RequestBody Services s)
	{
		boolean isServices=ServicesService.isServicesExists(ServicesId);
		if(isServices)
		{
			return new ResponseEntity<>(ServicesService.updateServices(ServicesId, s),HttpStatus.OK);
		}
		else {
			System.out.print("No Services found");
			return null;
		}
	}
	@DeleteMapping("/delete/{ServicesId}")
	public Services deleteServicesById(@PathVariable Long ServicesId)
	{
		
			return ServicesService.deleteServicesById(ServicesId);
		}
	
//	public void deleteServicesById(@PathVariable Long ServicesId)
//	{
//		boolean isServices=ServicesService.isServicesExists(ServicesId);
//		if(isServices)
//		{
//			ServicesService.deleteServicesById(ServicesId);
//		}
//		else
//		{
//			System.out.print("No Services found");
//		}
//	}
	@DeleteMapping("/deleteAll")
	public void deleteAllServices(){
		ServicesService.deleteAllServices();
	}
}



