package com.example.kgdcs.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import com.example.kgdcs.entity.EnrollForm;

@Entity
@Table(name="payment")
public class Payment {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="paymentId")
	private Long id;
	
	@Column(nullable = false)
	private Date date;
	
	@Column(nullable = false)
	private int enrollmentNumber;
	
	@Column(nullable = false)
	private Double totalAmount;
	
	@Column(nullable = false)
	private int discountAmount;
	
	@Column(nullable = false)
	private String paymenttype;
	
	
	/*@OneToOne(mappedBy = "enrollform")
	private EnrollForm enrollform;*/

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payment(Date date, int enrollmentNumber, Double totalAmount, int discountAmount, String paymenttype) {
		super();
		this.date = date;
		this.enrollmentNumber = enrollmentNumber;
		this.totalAmount = totalAmount;
		this.discountAmount = discountAmount;
		//this.netAmount = netAmount;
		this.paymenttype = paymenttype;
		//this.enrollform = enrollform;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getEnrollmentNumber() {
		return enrollmentNumber;
	}

	public void setEnrollmentNumber(int enrollmentNumber) {
		this.enrollmentNumber = enrollmentNumber;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(int discountAmount) {
		this.discountAmount = discountAmount;
	}

	/*public Double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}
*/
	public String getPaymenttype() {
		return paymenttype;
	}

	public void setPaymenttype(String paymenttype) {
		this.paymenttype = paymenttype;
	}

	/*public EnrollForm getEnrollform() {
		return enrollform;
	}

	public void setEnrollform(EnrollForm enrollform) {
		this.enrollform = enrollform;
	}
	*/
	
}