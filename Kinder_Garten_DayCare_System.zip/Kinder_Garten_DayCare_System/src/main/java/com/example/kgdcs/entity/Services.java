package com.example.kgdcs.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="services")
public class Services {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "serviceId")
	private int id;
	
	@Column(nullable = false,length=15)
	private String servicename;
	
	@Column(nullable = false,length=50)
	private String servicedetail;
	
	@Column(nullable = false)
	private Date creationdate=new Date();
	
	 @ManyToOne
	 @JoinColumn(name = "adminId" , referencedColumnName ="Id" )
	 private Admin admin;
	
	public Services() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Services(String servicename, String servicedetail, Date creationdate, Admin admin) {
		super();
		this.servicename = servicename;
		this.servicedetail = servicedetail;
		this.creationdate = creationdate;
		this.admin = admin;
	}

	public String getServicename() {
		return servicename;
	}

	public void setServicename(String servicename) {
		this.servicename = servicename;
	}

	public String getServicedetail() {
		return servicedetail;
	}

	public void setServicedetail(String servicedetail) {
		this.servicedetail = servicedetail;
	}

	public Date getCreationdate() {
		return creationdate;
	}

	public void setCreationdate(Date creationdate) {
		this.creationdate = creationdate;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	
}
