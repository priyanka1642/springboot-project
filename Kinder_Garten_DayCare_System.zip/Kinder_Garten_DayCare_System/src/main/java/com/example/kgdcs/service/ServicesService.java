package com.example.kgdcs.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.kgdcs.entity.Services;

@Component
public interface ServicesService {
	Services addServices(Services Services);
	
	List<Services> getAllServicess();
	
	Services getServicesById(Long ServicesId);
	
	Services updateServices(Long ServicesId,Services Services);
	
	Services deleteServicesById(Long ServicesId);
	
	void deleteAllServices();
	
	boolean isServicesExists(Long ServicesId);
	

}
