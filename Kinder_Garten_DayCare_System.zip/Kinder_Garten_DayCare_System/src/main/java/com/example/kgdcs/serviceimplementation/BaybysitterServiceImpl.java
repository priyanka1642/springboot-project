package com.example.kgdcs.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.kgdcs.entity.Babysitter;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.BabysitterRepository;
import com.example.kgdcs.service.BabysitterService;

@Service
public class BaybysitterServiceImpl implements BabysitterService {
    @Autowired
	 private BabysitterRepository BabysitterRepo;
    
	@Override
	public Babysitter addBabysitter(Babysitter Babysitter) {
		return BabysitterRepo.save(Babysitter);
	}

	@Override
	public List<Babysitter> getAllBabysitters() {
		return BabysitterRepo.findAll();
	}
	@Override
	public Babysitter getBabysitterById(Long BabysitterId) {
		
		Babysitter b;
		Optional<Babysitter>babysitter=BabysitterRepo.findById(BabysitterId);
		if(babysitter.isPresent())
		{
		 b=babysitter.get();
		}
		else
		{
			throw new ResourceNotFoundException("Babysitter","BabysitterId",BabysitterId);
		}
		return b;
	}

	@Override
	public Babysitter updateBabysitter(Long BabysitterId,Babysitter Babysitter) {
		Babysitter b=BabysitterRepo.findById(BabysitterId).get();
		b.setName(Babysitter.getName());
		b.setEmail(Babysitter.getEmail());
		b.setMobileno(Babysitter.getMobileno());
		b.setAddress(Babysitter.getAddress());
		b.setExperience(Babysitter.getExperience());
		b.setLanguagesknown(Babysitter.getLanguagesknown());
		b.setCertificate(Babysitter.getCertificate());
		b.setProfile(Babysitter.getProfile());
		return BabysitterRepo.save(b);
	}

	@Override
	public Babysitter deleteBabysitterById(Long BabysitterId) {
		 Optional<Babysitter> babysitterOptional = BabysitterRepo.findById(BabysitterId);
		    if (babysitterOptional.isPresent()) {
		    	BabysitterRepo.deleteById(BabysitterId);
		    } else {
		        throw new ResourceNotFoundException("Babysitter", "BabysitterId", BabysitterId);
		    }
			return null;
		}


	@Override
	public void deleteAllBabysitter() {
		BabysitterRepo.deleteAll();
		
	}

	@Override
	public boolean isBabysitterExists(Long BabysitterId) {
		return BabysitterRepo.existsById(BabysitterId);
	}

}




