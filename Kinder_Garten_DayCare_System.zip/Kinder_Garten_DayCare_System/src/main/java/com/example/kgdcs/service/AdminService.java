package com.example.kgdcs.service;

import java.util.List;


import com.example.kgdcs.entity.Admin;

public interface AdminService {
	Admin addAdmin(Admin Admin);
	
	List<Admin> getAllAdmins();
	
	Admin getAdminById(Long AdminId);
	
	Admin updateAdmin(Long AdminId,Admin Admin);
	
	Admin deleteAdminById(Long AdminId);
	
	void deleteAllAdmin();
	
	boolean isAdminExists(Long AdminId);
	

}
