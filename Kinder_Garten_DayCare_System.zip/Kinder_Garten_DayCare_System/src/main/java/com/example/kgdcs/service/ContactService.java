package com.example.kgdcs.service;

import java.util.List;

import com.example.kgdcs.entity.Contact;

public interface ContactService {
	Contact addContact(Contact Contact);
	
	List<Contact> getAllContacts();
	
	Contact getContactById(Long ContactId);
	
	Contact updateContact(Long ContactId,Contact Contact);
	
	Contact deleteContactById(Long ContactId);
	
	void deleteAllContact();
	
	boolean isContactExists(Long ContactId);
	

}

