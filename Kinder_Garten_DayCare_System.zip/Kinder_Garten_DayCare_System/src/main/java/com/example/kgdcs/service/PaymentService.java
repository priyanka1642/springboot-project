package com.example.kgdcs.service;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.kgdcs.entity.Payment;

@Component
public interface PaymentService {
	Payment addPayment(Payment Payment);
	
	List<Payment> getAllPayments();
	
	Payment getPaymentById(Long PaymentId);
	
	Payment updatePayment(Long PaymentId,Payment Payment);
	
	Payment deletePaymentById(Long PaymentId);
	
	void deleteAllPayment();
	
	boolean isPaymentExists(Long PaymentId);
	

}
