package com.example.kgdcs.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.kgdcs.entity.EnrollForm;
import com.example.kgdcs.service.EnrollFormService;


@RestController
@RequestMapping("/enrollform")
public class EnrollFormController {
	@Autowired
	private EnrollFormService EnrollFormService;
	
	@PostMapping("/add")
	public ResponseEntity<EnrollForm> addEnrollForm(@RequestBody EnrollForm EnrollForm)
	{
		EnrollForm u=EnrollFormService.addEnrollForm(EnrollForm);
		return new ResponseEntity<>(u,HttpStatus.CREATED);
	}
	@GetMapping("/get/{EnrollFormId}")
	public EnrollForm getEnrollForm(@PathVariable Long EnrollFormId)
	{
		
			return EnrollFormService.getEnrollFormById(EnrollFormId);
		}
	
//	public ResponseEntity<EnrollForm> getEnrollForm(@PathVariable Long EnrollFormId)
//	{
//		boolean isEnrollForm=EnrollFormService.isEnrollFormExists(EnrollFormId);
//		if(isEnrollForm)
//		{
//			EnrollForm u=EnrollFormService.getEnrollFormById(EnrollFormId);
//			return new ResponseEntity<>(u,HttpStatus.OK);
//		}
//		else
//		{
//			System.out.print("No EnrollForm found");
//			return null;
//		}
//	}
	@GetMapping("/getAll")
	public ResponseEntity<List<EnrollForm>> getAllEnrollForm(){
		return new ResponseEntity<>(EnrollFormService.getAllEnrollForms(),HttpStatus.OK);
	}
	@PutMapping("/update/{EnrollFormId}")
	public ResponseEntity<EnrollForm> updateEnrollForm(@PathVariable Long EnrollFormId,@RequestBody EnrollForm u)
	{
		boolean isEnrollForm=EnrollFormService.isEnrollFormExists(EnrollFormId);
		if(isEnrollForm)
		{
			return new ResponseEntity<>(EnrollFormService.updateEnrollForm(EnrollFormId, u),HttpStatus.OK);
		}
		else {
			System.out.print("No EnrollForm found");
			return null;
		}
	}
	@DeleteMapping("/delete/{EnrollFormId}")
	public EnrollForm deleteEnrollFormById(@PathVariable Long EnrollFormId)
	{
		
			return EnrollFormService.deleteEnrollFormById(EnrollFormId);
		}
	
//	public void deleteEnrollFormById(@PathVariable Long EnrollFormId)
//	{
//		boolean isEnrollForm=EnrollFormService.isEnrollFormExists(EnrollFormId);
//		if(isEnrollForm)
//		{
//			EnrollFormService.deleteEnrollFormById(EnrollFormId);
//		}
//		else
//		{
//			System.out.print("No EnrollForm found");
//		}
//	}
	@DeleteMapping("/deleteAll")
	public void deleteAllEnrollForm(){
		EnrollFormService.deleteAllEnrollForm();
	}
}




