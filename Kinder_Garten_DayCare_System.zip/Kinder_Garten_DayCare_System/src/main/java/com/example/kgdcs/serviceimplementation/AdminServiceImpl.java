package com.example.kgdcs.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.kgdcs.entity.Admin;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.AdminRepository;
import com.example.kgdcs.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
	 private AdminRepository AdminRepo;
    
	@Override
	public Admin addAdmin(Admin Admin) {
		return AdminRepo.save(Admin);
	}

	@Override
	public List<Admin> getAllAdmins() {
		return AdminRepo.findAll();
	}

	@Override
	public Admin getAdminById(Long AdminId) {
		Admin a;
		Optional<Admin>admin=AdminRepo.findById(AdminId);
		if(admin.isPresent())
		{
		 a=admin.get();
		}
		else
		{
			throw new ResourceNotFoundException("Admin","AdminId",AdminId);
		}
		return a;
	}

	@Override
	public Admin updateAdmin(Long AdminId,Admin admin) {
	Admin a=AdminRepo.findById(AdminId).get();
	
		a.setName(admin.getName());
		a.setUsername(admin.getUsername());
		a.setPassword(admin.getPassword());
		a.setEmail(admin.getEmail());
		a.setMobilenumber(admin.getMobilenumber());
		AdminRepo.save(a);
		
		return a;
	}
		
	@Override
	public Admin deleteAdminById(Long adminId) {
	    Optional<Admin> adminOptional = AdminRepo.findById(adminId);
	    if (adminOptional.isPresent()) {
	        AdminRepo.deleteById(adminId);
	    } else {
	        throw new ResourceNotFoundException("Admin", "AdminId", adminId);
	    }
		return null;
	}


	@Override
	public void deleteAllAdmin() {
		AdminRepo.deleteAll();
		
	}

	@Override
	public boolean isAdminExists(Long AdminId) {
		return AdminRepo.existsById(AdminId);
	}

}




