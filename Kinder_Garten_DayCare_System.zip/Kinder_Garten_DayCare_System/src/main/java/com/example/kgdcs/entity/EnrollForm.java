package com.example.kgdcs.entity;

import java.util.Date;

//import com.example.kgdcs.entity.Payment;
//import com.example.kgdcs.entity.Services;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="enrollform")
public class EnrollForm {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private int enrollmentnumber;
	
	@Column(nullable = false)
	private String parentName;
	
	@Column(nullable = false)
	private long phoneNumber;
	
	@Column(nullable = false)
	private String email;
	
	@Column(nullable = false)
	private String childName;
	
	@Column(nullable = false)
	private Date dob;
	
	@Column(nullable = false)
	private String gender;
	
	@Column(nullable = false)
	private String programName;
	
	@Column(nullable = false)
	private String address;
	
	//@Column(nullable = false)
	//private int zipcode;
	
	@Column(nullable = false)
	private String city;
	
	//@Column(nullable = false)
	//private String state;
	//@Column(nullable = false)
	//private String country;
	//@Column(nullable = false)
	//private String landmark;
	
	@Column(nullable = false)
	private Date date;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "fk_paymentId",referencedColumnName = "paymentId")
	private Payment payment;

	//@OneToMany(cascade = CascadeType.ALL)
	//@JoinColumn(name = "fk_serviceId", referencedColumnName = "enrollFormId")
	//private Services services;
	
	public EnrollForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EnrollForm(int enrollmentnumber, String parentName, long phoneNumber, String email, String childName,
			Date dob, String gender, String programName, String address, String city, Date date, Payment payment) {
		super();
		this.enrollmentnumber = enrollmentnumber;
		this.parentName = parentName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.childName = childName;
		this.dob = dob;
		this.gender = gender;
		this.programName = programName;
		this.address = address;
		//this.zipcode = zipcode;
		this.city = city;
		//this.state = state;
		//this.country = country;
		//this.landmark = landmark;
		this.date = date;
		this.payment = payment;
	}

	

	public int getEnrollmentnumber() {
		return enrollmentnumber;
	}

	public void setEnrollmentnumber(int enrollmentnumber) {
		this.enrollmentnumber = enrollmentnumber;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	/*public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
*/
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
/*
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
*/
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	/*public Services getServices() {
		return services;
	}

	public void setServices(Services services) {
		this.services = services;
	}
	*/
}
