package com.example.kgdcs.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.kgdcs.entity.Contact;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.ContactRepository;
import com.example.kgdcs.service.ContactService;

@Service
public class ContactServiceImpl implements ContactService {
    @Autowired
	 private ContactRepository ContactRepo;
    
	@Override
	public Contact addContact(Contact Contact) {
		return ContactRepo.save(Contact);
	}

	@Override
	public List<Contact> getAllContacts() {
		return ContactRepo.findAll();
	}

	@Override
	public Contact getContactById(Long ContactId) {

		Contact c;
		Optional<Contact>contact=ContactRepo.findById(ContactId);
		if(contact.isPresent())
		{
		 c=contact.get();
		}
		else
		{
			throw new ResourceNotFoundException("contact","ContactId",ContactId);
		}
		return c;
	}

	@Override
	public Contact updateContact(Long ContactId,Contact Contact) {
		Contact c=ContactRepo.findById(ContactId).get();
		c.setFirstname(Contact.getFirstname());
		c.setLastname(Contact.getLastname());
		c.setEmail(Contact.getEmail());
		c.setPhone(Contact.getPhone());
		c.setMessage(Contact.getMessage());
		c.setDate(Contact.getDate());
		return ContactRepo.save(c);
	}

	@Override
	public Contact deleteContactById(Long ContactId) {
		  Optional<Contact> contactOptional = ContactRepo.findById(ContactId);
		    if (contactOptional.isPresent()) {
		    	ContactRepo.deleteById(ContactId);
		    } else {
		        throw new ResourceNotFoundException("Contact", "ContactId", ContactId);
		    }
		return null;
		}


	@Override
	public void deleteAllContact() {
		ContactRepo.deleteAll();
		
	}

	@Override
	public boolean isContactExists(Long ContactId) {
		return ContactRepo.existsById(ContactId);
	}

}




