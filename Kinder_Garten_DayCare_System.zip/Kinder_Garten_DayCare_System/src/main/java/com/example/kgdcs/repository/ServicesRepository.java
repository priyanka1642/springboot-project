package com.example.kgdcs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.kgdcs.entity.Services;

public interface ServicesRepository extends JpaRepository<Services, Long>{



}
