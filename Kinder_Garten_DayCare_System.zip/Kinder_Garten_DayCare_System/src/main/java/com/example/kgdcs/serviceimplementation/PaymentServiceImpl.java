package com.example.kgdcs.serviceimplementation;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.kgdcs.entity.Payment;
import com.example.kgdcs.exception.ResourceNotFoundException;
import com.example.kgdcs.repository.PaymentRepository;
import com.example.kgdcs.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
    @Autowired
	 private PaymentRepository PaymentRepo;
    
	@Override
	public Payment addPayment(Payment Payment) {
		return PaymentRepo.save(Payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		return PaymentRepo.findAll();
	}

	@Override
	public Payment getPaymentById(Long PaymentId) {
		//Optional<Payment> op=PaymentRepo.findById(PaymentId);
		//return op.get();
		Payment p;
		Optional<Payment >payment=PaymentRepo.findById(PaymentId);
		if(payment.isPresent())
		{
		 p=payment.get();
		}
		else
		{
			throw new ResourceNotFoundException("Payment","PaymentId",PaymentId);
		}
		return p;
	}

	@Override
	public Payment updatePayment(Long PaymentId,Payment Payment) {
		Payment p=PaymentRepo.findById(PaymentId).get();
		p.setDate(Payment.getDate());
		p.setEnrollmentNumber(Payment.getEnrollmentNumber());
		p.setDiscountAmount(Payment.getDiscountAmount());
		p.setPaymenttype(Payment.getPaymenttype());
		p.setTotalAmount(Payment.getTotalAmount());
		return PaymentRepo.save(p);
	}

	@Override
	public Payment deletePaymentById(Long PaymentId) {
		  Optional<Payment> paymentOptional = PaymentRepo.findById(PaymentId);
		    if (paymentOptional.isPresent()) {
		    	PaymentRepo.deleteById(PaymentId);
		    } else {
		        throw new ResourceNotFoundException("Payment", "PaymentId", PaymentId);
		    }
			return null;
		}

	@Override
	public void deleteAllPayment() {
		PaymentRepo.deleteAll();
		
	}

	@Override
	public boolean isPaymentExists(Long PaymentId) {
		return PaymentRepo.existsById(PaymentId);
	}

}



