package com.example.kgdcs.service;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.kgdcs.entity.EnrollForm;

@Component
public interface EnrollFormService {
	EnrollForm addEnrollForm(EnrollForm EnrollForm);
	
	List<EnrollForm> getAllEnrollForms();
	
	EnrollForm getEnrollFormById(Long EnrollFormId);
	
	EnrollForm updateEnrollForm(Long EnrollFormId,EnrollForm EnrollForm);
	
	EnrollForm deleteEnrollFormById(Long EnrollFormId);
	
	void deleteAllEnrollForm();
	
	boolean isEnrollFormExists(Long EnrollFormId);
	

}
