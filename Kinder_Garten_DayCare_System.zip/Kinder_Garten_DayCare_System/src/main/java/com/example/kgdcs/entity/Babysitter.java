package com.example.kgdcs.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="babysitter")
public class Babysitter {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String email;
	
	@Column(nullable = false)
	private int mobileno;
	
	@Column(length = 10, nullable = false)
	private String address;
	
	//@Column(nullable = false)
	//private String city;
	//@Column(nullable = false)
	//private String state;
	
	@Column(nullable = false)
	private String languagesknown;
	
	@Column(nullable = false)
	private String experience;
	
	@Column(nullable = false)
	private String profile;
	
	@Column(nullable = false)
	private String certificate;
	
	//@Column(nullable = false)
	//private String description;
	//@Column(nullable = false)
	//private Date date;
	
	public Babysitter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Babysitter(int id, String name, String email, int mobileno, String address,
			String languagesknown, String experience, String profile, String certificate) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.mobileno = mobileno;
		this.address = address;
	//	this.city = city;
	//	this.state = state;
		this.languagesknown = languagesknown;
		this.experience = experience;
		this.profile = profile;
		this.certificate = certificate;
	//	this.description = description;
	//	this.date = date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	/*public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}*/
	public String getLanguagesknown() {
		return languagesknown;
	}
	public void setLanguagesknown(String languagesknown) {
		this.languagesknown = languagesknown;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	/*public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	*/
	
}

