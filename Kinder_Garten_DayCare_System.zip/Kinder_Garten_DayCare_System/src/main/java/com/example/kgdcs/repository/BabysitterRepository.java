package com.example.kgdcs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.kgdcs.entity.Babysitter;

public interface BabysitterRepository extends JpaRepository<Babysitter, Long>{

}
