package com.example.kgdcs.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.kgdcs.entity.EnrollForm;

public interface EnrollRepository extends JpaRepository<EnrollForm, Long> {

}
