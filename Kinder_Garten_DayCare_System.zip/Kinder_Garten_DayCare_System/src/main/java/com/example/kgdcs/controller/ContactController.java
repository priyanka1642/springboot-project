package com.example.kgdcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.kgdcs.entity.Contact;
import com.example.kgdcs.service.ContactService;

@RestController
@RequestMapping("/contact")
public class ContactController {
	@Autowired
	private ContactService ContactService;
	
	@PostMapping("/add")
	public ResponseEntity<Contact> addContact(@RequestBody Contact Contact)
	{
		Contact c=ContactService.addContact(Contact);
		return new ResponseEntity<>(c,HttpStatus.CREATED);
	}
	@GetMapping("/get/{ContactId}")
	public Contact getContact(@PathVariable Long ContactId)
	{
		
			return ContactService.getContactById(ContactId);
		}
	
//	public ResponseEntity<Contact> getContact(@PathVariable Long ContactId)
//	{
//		boolean isContact=ContactService.isContactExists(ContactId);
//		if(isContact)
//		{
//			Contact c=ContactService.getContactById(ContactId);
//			return new ResponseEntity<>(c,HttpStatus.OK);
//		}
//		else
//		{
//			System.out.print("No Contact found");
//			return null;
//		}
//	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Contact>> getAllContact(){
		return new ResponseEntity<>(ContactService.getAllContacts(),HttpStatus.OK);
	}
	@PutMapping("/update/{ContactId}")
	public ResponseEntity<Contact> updateContact(@PathVariable Long ContactId,@RequestBody Contact c)
	{
		boolean isContact=ContactService.isContactExists(ContactId);
		if(isContact)
		{
			return new ResponseEntity<>(ContactService.updateContact(ContactId, c),HttpStatus.OK);
		}
		else {
			System.out.print("No Contact found");
			return null;
		}
	}
	@DeleteMapping("/delete/{ContactId}")
	public Contact deleteContactById(@PathVariable Long ContactId)
	{
		
			return ContactService.deleteContactById(ContactId);
		}
	@DeleteMapping("/deleteAll")
	public void deleteAllContact(){
		ContactService.deleteAllContact();
	}
}




