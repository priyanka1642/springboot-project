package com.example.kgdcs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.kgdcs.entity.Babysitter;
import com.example.kgdcs.service.BabysitterService;

@RestController
@RequestMapping("/babysitter")
public class BabysitterController {
	@Autowired
	private BabysitterService BabysitterService;
	
	@PostMapping("/add")
	public ResponseEntity<Babysitter> addBabysitter(@RequestBody Babysitter Babysitter)
	{
		Babysitter b=BabysitterService.addBabysitter(Babysitter);
		return new ResponseEntity<>(b,HttpStatus.CREATED);
	}
	@GetMapping("/get/{BabysitterId}")
	public Babysitter getBabysitter(@PathVariable Long BabysitterId)
	{
		
			return BabysitterService.getBabysitterById(BabysitterId);
		}
//	public ResponseEntity<Babysitter> getBabysitter(@PathVariable Long BabysitterId)
//	{
//		boolean isBabysitter=BabysitterService.isBabysitterExists(BabysitterId);
//		if(isBabysitter)
//		{
//			Babysitter b=BabysitterService.getBabysitterById(BabysitterId);
//			return new ResponseEntity<>(b,HttpStatus.OK);
//		}
//		else
//		{
//			System.out.print("No Babysitter found");
//			return null;
//		}
//	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Babysitter>> getAllBabysitter(){
		return new ResponseEntity<>(BabysitterService.getAllBabysitters(),HttpStatus.OK);
	}
	@PutMapping("/update/{BabysitterId}")
	public ResponseEntity<Babysitter> updateBabysitter(@PathVariable Long BabysitterId,@RequestBody Babysitter b)
	{
		boolean isBabysitter=BabysitterService.isBabysitterExists(BabysitterId);
		if(isBabysitter)
		{
			return new ResponseEntity<>(BabysitterService.updateBabysitter(BabysitterId, b),HttpStatus.OK);
		}
		else {
			System.out.print("No Babysitter found");
			return null;
		}
	}
	@DeleteMapping("/delete/{BabysitterId}")
	public Babysitter deleteBabysitterById(@PathVariable Long BabysitterId)
	{
		
			return BabysitterService.deleteBabysitterById(BabysitterId);
	}
	
//	public void deleteBabysitterById(@PathVariable Long BabysitterId)
//	{
//		boolean isBabysitter=BabysitterService.isBabysitterExists(BabysitterId);
//		if(isBabysitter)
//		{
//			BabysitterService.deleteBabysitterById(BabysitterId);
//		}
//		else
//		{
//			System.out.print("No Babysitter found");
//		}
//	}
	@DeleteMapping("/deleteAll")
	public void deleteAllBabysitter(){
		BabysitterService.deleteAllBabysitter();
	}
}




