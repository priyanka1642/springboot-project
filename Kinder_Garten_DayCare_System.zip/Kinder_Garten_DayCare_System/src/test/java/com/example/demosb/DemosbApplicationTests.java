package com.example.demosb;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.kgdcs.entity.Admin;
import com.example.kgdcs.repository.AdminRepository;
//import com.example.kgdcs.service.AdminService;

@SpringBootTest
class DemosbApplicationTests {
	 @Autowired
	    private AdminRepository adminRepository;
	 

	    @Test
	    void contextLoads() {
	    }
	
	
	 public void testSaveAdmin() {
	     // Create a admin entity
	     Admin admin = new Admin();
	     admin.setName("john_doe");
	     admin.setUsername("john");
	     admin.setEmail("john@example.com");
	     admin.setPassword("john123"); // This should match the password set

	     // Save the admin entity
	     Admin savedAdmin = adminRepository.save(admin); // Changed AdminRepository to userRepository

	     // Retrieve the admin from the database
	     Admin retrievedAdmin = adminRepository.findById(savedAdmin.getId()).orElse(null); // Changed AdminRepository to userRepository

	     // Check if the retrieved user is not null
	     assertNotNull(retrievedAdmin);

	     // Check if the user properties are correctly saved
	     assertEquals("john_doe", retrievedAdmin.getName());
	     assertEquals("john", retrievedAdmin.getUsername());
	     assertEquals("john@example.com", retrievedAdmin.getEmail());
	     assertEquals("john123", retrievedAdmin.getPassword()); // Corrected password assertion
	 }
}